﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace AsgharProject
{
    public class Signup : BasePage
    {

        public void Sign(string user, string pass)
        {

            By log_in = By.Id("signin2");
            By usernameTxt = By.Id("sign-username");
            By passwordTxt = By.Id("sign-password");
            By loginbtn = By.XPath("/html/body/div[2]/div/div/div[3]/button[2]");


            driver.FindElement(log_in).Click();
            Thread.Sleep(3000);

            driver.FindElement(usernameTxt).SendKeys(user);

            driver.FindElement(passwordTxt).SendKeys(pass);
            Thread.Sleep(3000);
            driver.FindElement(loginbtn).Click();

            driver.Manage().Window.Maximize();
            // driver.Close();



        }

    }
}
