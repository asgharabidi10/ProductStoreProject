using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AsgharProject
{
    public class BasePage
    {
        public static IWebDriver driver;
        public void SeleniumInit(String url)
        {
            var mydriver = new ChromeDriver();
            driver = mydriver;
            driver.Url = url;

        }

    }
}




