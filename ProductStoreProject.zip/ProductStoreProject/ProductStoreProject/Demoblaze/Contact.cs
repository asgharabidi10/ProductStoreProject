﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace AsgharProject
{
    public class Contact : BasePage
    {
        public void contactus(String email, String name, String msg)
        {

            driver.Manage().Window.Maximize();
            By cont = By.XPath("/html/body/nav/div[1]/ul/li[2]/a");
            driver.FindElement(cont).Click();
            Thread.Sleep(3000);
            By emaail = By.Id("recipient-email");
            driver.FindElement(emaail).SendKeys(email);


            By naam = By.Id("recipient-name");
            driver.FindElement(naam).SendKeys(name);

            By message = By.Id("message-text");
            driver.FindElement(message).SendKeys(msg);

            By subbtn = By.XPath("/html/body/div[1]/div/div/div[3]/button[2]");
            driver.FindElement(subbtn).Click();

            Thread.Sleep(3000);
            driver.SwitchTo().Alert().Accept();
            driver.Close();

        }
    }
}
