﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace AsgharProject
{
    public class Category : BasePage
    {

        public void mobile(String name, String country, String city, string Credit, String month, string year)
        {
            driver.Manage().Window.Maximize();

            By phone = By.XPath("/html/body/div[5]/div/div[1]/div/a[2]");
            Thread.Sleep(3000);
            driver.FindElement(phone).Click();


            By mob = By.XPath("/html/body/div[5]/div/div[2]/div/div[1]/div/a/img");
            Thread.Sleep(3000);
            driver.FindElement(mob).Click();


            By add = By.XPath("/html/body/div[5]/div/div[2]/div[2]/div/a");
            Thread.Sleep(3000);
            driver.FindElement(add).Click();
            Thread.Sleep(3000);

            driver.SwitchTo().Alert().Accept();


            By cart = By.Id("cartur");
            Thread.Sleep(3000);
            driver.FindElement(cart).Click();

            By order = By.XPath("/html/body/div[6]/div/div[2]/button");
            Thread.Sleep(3000);
            driver.FindElement(order).Click();


            By naam = By.XPath("/html/body/div[3]/div/div/div[2]/form/div[1]/input");
            driver.FindElement(naam).SendKeys(name);

            By contry = By.XPath("/html/body/div[3]/div/div/div[2]/form/div[2]/input");
            driver.FindElement(contry).SendKeys(country);

            By citi = By.XPath("/html/body/div[3]/div/div/div[2]/form/div[3]/input");
            driver.FindElement(citi).SendKeys(city);


            By cred = By.XPath("/html/body/div[3]/div/div/div[2]/form/div[4]/input");
            driver.FindElement(cred).SendKeys(Credit);

            By mon = By.Id("/html/body/div[3]/div/div/div[2]/form/div[5]/input");
            driver.FindElement(mon).SendKeys(month);


            By yaar = By.Id("/html/body/div[3]/div/div/div[2]/form/div[6]/input");
            driver.FindElement(yaar).SendKeys(year);





            By procced = By.XPath("/html/body/div[3]/div/div/div[3]/button[2]");
            driver.FindElement(procced).Click();
            Thread.Sleep(3000);
            driver.SwitchTo().Alert().Accept();

            By actual = By.XPath("/html/body/div[10]/h2");

            Assert.AreEqual("Thank you for your purchase!", driver.FindElement(actual).Text);
            By okay = By.XPath("/html/body/div[10]/div[7]/div/button");
            driver.FindElement(okay).Click();
            driver.Close();


            driver.Close();

        }
        public void Laptop(String name, String country, String city, string Credit, String month, string year)
        {
            driver.Manage().Window.Maximize();
            By laptop = By.XPath("/html/body/div[5]/div/div[1]/div/a[3]");
            driver.FindElement(laptop).Click();



            By lab = By.XPath("/html/body/div[5]/div/div[2]/div/div[1]/div/a/img");
            Thread.Sleep(3000);
            driver.FindElement(lab).Click();


            By add = By.XPath("/html/body/div[5]/div/div[2]/div[2]/div/a");
            Thread.Sleep(3000);
            driver.FindElement(add).Click();
            Thread.Sleep(3000);

            driver.SwitchTo().Alert().Accept();


            By cart = By.Id("cartur");
            Thread.Sleep(3000);
            driver.FindElement(cart).Click();

            By order = By.XPath("/html/body/div[6]/div/div[2]/button");
            Thread.Sleep(3000);
            driver.FindElement(order).Click();


            By naam = By.XPath("/html/body/div[3]/div/div/div[2]/form/div[1]/input");
            driver.FindElement(naam).SendKeys(name);

            By contry = By.XPath("/html/body/div[3]/div/div/div[2]/form/div[2]/input");
            driver.FindElement(contry).SendKeys(country);

            By citi = By.XPath("/html/body/div[3]/div/div/div[2]/form/div[3]/input");
            driver.FindElement(citi).SendKeys(city);


            By cred = By.XPath("/html/body/div[3]/div/div/div[2]/form/div[4]/input");
            driver.FindElement(cred).SendKeys(Credit);

            By mon = By.Id("/html/body/div[3]/div/div/div[2]/form/div[5]/input");
            driver.FindElement(mon).SendKeys(month);


            By yaar = By.Id("/html/body/div[3]/div/div/div[2]/form/div[6]/input");
            driver.FindElement(yaar).SendKeys(year);





            By procced = By.XPath("/html/body/div[3]/div/div/div[3]/button[2]");
            driver.FindElement(procced).Click();
            Thread.Sleep(3000);
            driver.SwitchTo().Alert().Accept();

            By actual = By.XPath("/html/body/div[10]/h2");

            Assert.AreEqual("Thank you for your purchase!", driver.FindElement(actual).Text);
            By okay = By.XPath("/html/body/div[10]/div[7]/div/button");
            driver.FindElement(okay).Click();
            driver.Close();


            driver.Close();

            //driver.Close();

        }
        public void Monitor(String name, String country, String city, string Credit, String month, string year)
        {
            driver.Manage().Window.Maximize();

            By monitor = By.XPath("/html/body/div[5]/div/div[1]/div/a[4]");
            driver.FindElement(monitor).Click();


            By mon = By.XPath("/html/body/div[5]/div/div[2]/div/div[1]/div/a/img");
            Thread.Sleep(3000);
            driver.FindElement(mon).Click();


            By add = By.XPath("/html/body/div[5]/div/div[2]/div[2]/div/a");
            Thread.Sleep(3000);
            driver.FindElement(add).Click();
            Thread.Sleep(3000);

            driver.SwitchTo().Alert().Accept();


            By cart = By.Id("cartur");
            Thread.Sleep(3000);
            driver.FindElement(cart).Click();

            By order = By.XPath("/html/body/div[6]/div/div[2]/button");
            Thread.Sleep(3000);
            driver.FindElement(order).Click();


            By naam = By.XPath("/html/body/div[3]/div/div/div[2]/form/div[1]/input");
            driver.FindElement(naam).SendKeys(name);

            By contry = By.XPath("/html/body/div[3]/div/div/div[2]/form/div[2]/input");
            driver.FindElement(contry).SendKeys(country);

            By citi = By.XPath("/html/body/div[3]/div/div/div[2]/form/div[3]/input");
            driver.FindElement(citi).SendKeys(city);


            By cred = By.XPath("/html/body/div[3]/div/div/div[2]/form/div[4]/input");
            driver.FindElement(cred).SendKeys(Credit);

            By months = By.Id("/html/body/div[3]/div/div/div[2]/form/div[5]/input");
            driver.FindElement(months).SendKeys(month);


            By yaar = By.Id("/html/body/div[3]/div/div/div[2]/form/div[6]/input");
            driver.FindElement(yaar).SendKeys(year);





            By procced = By.XPath("/html/body/div[3]/div/div/div[3]/button[2]");
            driver.FindElement(procced).Click();
            Thread.Sleep(3000);
            driver.SwitchTo().Alert().Accept();

            By actual = By.XPath("/html/body/div[10]/h2");

            Assert.AreEqual("Thank you for your purchase!", driver.FindElement(actual).Text);
            By okay = By.XPath("/html/body/div[10]/div[7]/div/button");
            driver.FindElement(okay).Click();
            driver.Close();


            driver.Close();

            //driver.Close();

        }
    }
}
