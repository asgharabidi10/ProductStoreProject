﻿
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Security.Policy;
using System.Threading;
using System.Windows;

namespace AsgharProject
{
    [TestClass]
    public class LoginPage : BasePage
    {

        public void Login(string user, string pass)
        {

            By log_in = By.Id("login2");
            By usernameTxt = By.XPath("/html/body/div[3]/div/div/div[2]/form/div[1]/input");
            By passwordTxt = By.XPath("/html/body/div[3]/div/div/div[2]/form/div[2]/input");
            By loginbtn = By.XPath("/html/body/div[3]/div/div/div[3]/button[2]");


            driver.Manage().Window.Maximize();
            driver.FindElement(log_in).Click();
            Thread.Sleep(3000);
            driver.FindElement(usernameTxt).SendKeys(user);
            driver.FindElement(passwordTxt).SendKeys(pass);


            driver.FindElement(loginbtn).Click();
            Thread.Sleep(3000);
            driver.SwitchTo().Alert().Accept();

            driver.Close();



        }



    }
}