﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ProductStoreProject
{
    [TestClass]
    public class TestClass
    {
        LoginPage login = new LoginPage();
        BasePage basePage = new BasePage();
        Signup sign = new Signup();
        Contact cont = new Contact();
        Category cat = new Category();
        AddToCart product = new AddToCart();

        [TestMethod]
        public void TestCase_001()
        {
            basePage.SeleniumInit("https://www.demoblaze.com/index.html");
            login.Login("asghar100", "asghar110");

        }

        [TestMethod]
        public void TestCase_002()
        {
            basePage.SeleniumInit("https://www.demoblaze.com/index.html");
            sign.Sign("asghar101@gmail.com", "asghar");

        }
        [TestMethod]
        public void TestCase_003()
        {
            basePage.SeleniumInit("https://www.demoblaze.com/index.html");
            cont.contactus("asghar@hotmail.com", "asghar", "hello sir how are you");
        }

        [TestMethod]
        public void TestClass_004()
        {
            basePage.SeleniumInit("https://www.demoblaze.com/index.html");
            cat.mobile("asghar", "pakistan", "karachi", "7377772882", "january", "2022");



        }

        [TestMethod]
        public void TestClass_005()
        {
            basePage.SeleniumInit("https://www.demoblaze.com/index.html");
            cat.Laptop("asghar", "pakistan", "karachi", "7377772882", "january", "2022");
        }

        [TestMethod]
        public void TestClass_006()
        {
            basePage.SeleniumInit("https://www.demoblaze.com/index.html");
            cat.Monitor("asghar", "pakistan", "karachi", "7377772882", "january", "2022");
        }

        [TestMethod]
        public void TestClass_007()
        {
            basePage.SeleniumInit("https://www.demoblaze.com/index.html");
            product.Product();

        }
        [TestMethod]
        public void TestClass_008()
        {
            basePage.SeleniumInit("https://www.demoblaze.com/index.html");
            product.Cart("asghar", "pakistan", "karachi", "7377772882", "january", "2022");
        }

        [TestMethod]
        [TestCategory("NeagtiveTestCases")]
        public void TestCase_009()
        {
            basePage.SeleniumInit("https://www.demoblaze.com/index.html");
            login.Login("asgharabidi@gmail.com", "asghar");

        }
        [TestMethod]
        [TestCategory("NeagtiveTestCases")]
        public void TestCase_0010()
        {
            basePage.SeleniumInit("https://www.demoblaze.com/index.html");
            login.Login("asghar@gmail.com", "asghar");

        }
        [TestMethod]
        [TestCategory("NeagtiveTestCases")]
        public void TestCase_0011()
        {
            basePage.SeleniumInit("https://www.demoblaze.com/index.html");
            sign.Sign("", "abidi");

        }
        [TestMethod]
        [TestCategory("NeagtiveTestCases")]
        public void TestCase_0012()
        {
            basePage.SeleniumInit("https://www.demoblaze.com/index.html");
            sign.Sign("asgharabidi@gmail.com", "");

        }
        [TestMethod]
        [TestCategory("NeagtiveTestCases")]
        public void TestCase_0013()
        {
            basePage.SeleniumInit("https://www.demoblaze.com/index.html");
            sign.Sign("", "");

        }

        [TestMethod]
        [TestCategory("NeagtiveTestCases")]
        public void TestCase_0014()
        {
            basePage.SeleniumInit("https://www.demoblaze.com/index.html");
            login.Login("", "");

        }

    }
}

